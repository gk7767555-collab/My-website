STUDY MASTER - Designed by Gautam
================================

यह शुरुआती वेबसाइट/PWA प्रोजेक्ट है।

मोबाइल पर देखने के लिए:
1. ZIP फाइल को extract/unzip करें।
2. index.html को ब्राउज़र में खोलें।
3. इंटरनेट पर प्रकाशित करने के लिए GitHub repository में index.html, manifest.json और sw.js तीनों अपलोड करें।
4. GitHub Pages में Deploy होने के बाद वेबसाइट लिंक खोलें।
5. Chrome के menu में "Add to Home screen" या "Install app" दिखे तो उससे मोबाइल में ऐप जैसा उपयोग कर सकते हैं।

ध्यान दें:
- यह अभी शुरुआती demo है; Class 1-12 और सभी boards की पूरी अध्ययन सामग्री इसमें नहीं है।
- Profile में नाम इसी डिवाइस के browser में सेव होता है; यह असली सुरक्षित online login नहीं है।
- Android APK बनाने के लिए आगे अलग packaging/build प्रक्रिया होगी।
- असली student accounts, online results और leaderboard के लिए सुरक्षित backend/database जोड़ना होगा।
